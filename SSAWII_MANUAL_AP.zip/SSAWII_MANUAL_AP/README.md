# manual_spyrosadventurewii
Manual Archipelago for Skylanders Spyro's Adventure Wii. Compatable with the latest release of Archipelago (0.6.7)
Contains a seperate apwworld and playing guide for Glitched and Glitchlesss logic


READ THE PLAYING GUIDE FOR ALL RULES BEFORE STARTING

Information and Setup Guide for Archipelago available at /https://archipelago.gg/tutorial/Archipelago/setup_en


Created by DukeDragon28, to be freely modified. If you do, please maintain credit

Credit for bug reports: Kory (typos)


Version 1.1.0
